package com.hcl.mi.requestdtos;

import lombok.Data;

@Data
public class LoginRequestDto {
	
	private String username;
	
	private String password;
}
