package com.hcl.mi.exceptions;

public class InvalidElementException extends Exception{
	
	public InvalidElementException(String msg) {
		super(msg);
	}
}
