package com.hcl.mi.exceptions;

public class GenericAlreadyExistsException extends RuntimeException {
    public GenericAlreadyExistsException(String message) {
        super(message);
    }
}
