package com.hcl.mi.exceptions;

public class DuplicateCharacteristicException extends RuntimeException {
    public DuplicateCharacteristicException(String message) {
        super(message);
    }
}
