package com.hcl.mi;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;


@SpringBootApplication
@EnableTransactionManagement
@OpenAPIDefinition(info = @Info(title = "Material Inspection Service", 
                                description = "Capturing Inspection Actuals details.",
                                contact = @Contact(name = "Siva", 
                                email = "siva@hcltech.com")))
public class MaterialInspectionRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaterialInspectionRestApplication.class, args);
		
	}

}
