package com.hcl.mi.responsedtos;

import lombok.Data;

@Data
public class EmployeeDTO {
	
	private String empName;
	
	private String departmentName;
	
	private Integer salary;
	
	private String gender;
}
