package com.hcl.mi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaterialInspectionRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
